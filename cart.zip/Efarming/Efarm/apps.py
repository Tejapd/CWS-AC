from django.apps import AppConfig


class EfarmConfig(AppConfig):
    name = 'Efarm'
